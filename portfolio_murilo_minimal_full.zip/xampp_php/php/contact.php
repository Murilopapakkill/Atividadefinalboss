<?php
header('Content-Type: application/json; charset=utf-8');
require_once 'db.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success'=>false,'error'=>'Método inválido']);
    exit;
}
$name = trim($_POST['name'] ?? '');
$email = trim($_POST['email'] ?? '');
$message = trim($_POST['message'] ?? '');
if (!$name || !$email || !$message) {
    echo json_encode(['success'=>false,'error'=>'Todos os campos são obrigatórios']);
    exit;
}
$mysqli = get_db();
$stmt = $mysqli->prepare("INSERT INTO messages (name, email, message, created_at) VALUES (?, ?, ?, NOW())");
if (!$stmt) {
    echo json_encode(['success'=>false,'error'=>'Prepare failed: '.$mysqli->error]);
    exit;
}
$stmt->bind_param('sss', $name, $email, $message);
$ok = $stmt->execute();
if (!$ok) {
    echo json_encode(['success'=>false,'error'=>'Execute failed: '.$stmt->error]);
} else {
    echo json_encode(['success'=>true]);
}
$stmt->close();
$mysqli->close();
?>