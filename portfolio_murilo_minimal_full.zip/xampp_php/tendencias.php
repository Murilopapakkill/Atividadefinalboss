<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Tendências Tecnológicas — Murilo</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
  <nav class="navbar">
  <div class="container nav-row">
    <a class="brand" href="home.php">Murilo Teixeira</a>
    <ul class="nav-links">
      <li><a href="home.php">Home</a></li>
      <li><a href="sobre.php">Sobre</a></li>
      <li><a href="habilidades.php">Habilidades</a></li>
      <li><a href="softskills.php">Soft Skills</a></li>
      <li><a href="areas_overview.php">Áreas</a></li>
      <li><a href="tendencias.php">Tendências</a></li>
      <li><a href="contato.php">Contato</a></li>
    </ul>
    <a class="login" href="login.php">Admin</a>
  </div>
</nav>
  <main class="container">
    <header class="header">
      <h1>Tendências Tecnológicas</h1>
    </header>
    <section class="card">
      <p>Veja as páginas separadas sobre Cibersegurança, Blockchain, Robótica e Edge Computing.</p><ul><li><a href='t_ciberseg.php'>Cibersegurança</a></li><li><a href='t_blockchain.php'>Blockchain</a></li><li><a href='t_robotica.php'>Robótica e Automação</a></li><li><a href='t_edge.php'>Edge Computing</a></li></ul>
    </section>
    <footer class="footer">
      <p>Murilo Teixeira de Sousa — 17 anos — 3º ano EM & Curso Técnico em TI</p>
    </footer>
  </main>
</body>
</html>