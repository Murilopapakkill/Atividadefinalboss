<?php
// login.php
?>
<!doctype html><html><head><meta charset="utf-8"><title>Login — Murilo</title><link rel="stylesheet" href="css/style.css"></head><body>
<nav class="navbar"><div class="container nav-row"><a class="brand" href="home.php">Murilo Teixeira</a></div></nav>
<main class="container">
  <h1>Login</h1>
  <div class="card">
    <form action="admin.php" method="post">
      <label>Usuário<input name="user" required></label>
      <label>Senha<input type="password" name="pass" required></label>
      <button type="submit">Entrar</button>
    </form>
  </div>
</main>
</body></html>
