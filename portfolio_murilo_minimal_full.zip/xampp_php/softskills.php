<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Soft Skills — Murilo</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
  <nav class="navbar">
  <div class="container nav-row">
    <a class="brand" href="home.php">Murilo Teixeira</a>
    <ul class="nav-links">
      <li><a href="home.php">Home</a></li>
      <li><a href="sobre.php">Sobre</a></li>
      <li><a href="habilidades.php">Habilidades</a></li>
      <li><a href="softskills.php">Soft Skills</a></li>
      <li><a href="areas_overview.php">Áreas</a></li>
      <li><a href="tendencias.php">Tendências</a></li>
      <li><a href="contato.php">Contato</a></li>
    </ul>
    <a class="login" href="login.php">Admin</a>
  </div>
</nav>
  <main class="container">
    <header class="header">
      <h1>Soft Skills</h1>
    </header>
    <section class="card">
      <p>Proatividade, organização, trabalho em equipe, comunicação e aprendizado rápido. Essas competências me ajudam em projetos em grupo e em resolver problemas técnicos.</p>
    </section>
    <footer class="footer">
      <p>Murilo Teixeira de Sousa — 17 anos — 3º ano EM & Curso Técnico em TI</p>
    </footer>
  </main>
</body>
</html>