
-- create_db.sql
CREATE DATABASE IF NOT EXISTS portfolio_murilo CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE portfolio_murilo;

CREATE TABLE IF NOT EXISTS messages (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  email VARCHAR(150) NOT NULL,
  message TEXT NOT NULL,
  created_at DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- sample messages (12) to reach 12 records; you can add projects separately if needed
INSERT INTO messages (name,email,message,created_at) VALUES
('Ana Silva','ana@example.com','Ótimo portfólio!','2025-01-10 12:01:00'),
('João Pereira','joao@example.com','Gostaria de saber mais sobre o projeto X.','2025-01-11 08:22:00'),
('Mariana Lima','mariana@example.com','Parabéns, muito bom!','2025-01-12 16:30:00'),
('Carlos Souza','carlos@example.com','Tem como enviar o código fonte?','2025-01-13 09:10:00'),
('Paula Ramos','paula@example.com','Interessado em parceria.','2025-01-14 14:45:00'),
('Rafael Costa','rafael@example.com','Onde estudou isso?','2025-01-15 11:15:00'),
('Beatriz Alves','beatriz@example.com','Excelente apresentação.','2025-01-16 10:05:00'),
('Lucas Rocha','lucas@example.com','Ficou ótimo no mobile.','2025-01-17 19:00:00'),
('Juliana Mata','juliana@example.com','Posso usar seu projeto como referência?','2025-01-18 13:30:00'),
('Pedro Nunes','pedro@example.com','Me adicione no GitHub.','2025-01-19 07:45:00'),
('Renata Dias','renata@example.com','Tem curso online?','2025-01-20 18:20:00'),
('Felipe Martins','felipe@example.com','Como vc fez a parte do banco?','2025-01-21 21:10:00');
