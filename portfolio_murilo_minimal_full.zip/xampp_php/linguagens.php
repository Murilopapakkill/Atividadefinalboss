<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Linguagens e suas Tecnologias — Murilo</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
  <nav class="navbar">
  <div class="container nav-row">
    <a class="brand" href="home.php">Murilo Teixeira</a>
    <ul class="nav-links">
      <li><a href="home.php">Home</a></li>
      <li><a href="sobre.php">Sobre</a></li>
      <li><a href="habilidades.php">Habilidades</a></li>
      <li><a href="softskills.php">Soft Skills</a></li>
      <li><a href="areas_overview.php">Áreas</a></li>
      <li><a href="tendencias.php">Tendências</a></li>
      <li><a href="contato.php">Contato</a></li>
    </ul>
    <a class="login" href="login.php">Admin</a>
  </div>
</nav>
  <main class="container">
    <header class="header">
      <h1>Linguagens e suas Tecnologias</h1>
    </header>
    <section class="card">
      <h3 class="section-title">Linguagens e suas Tecnologias</h3>
<section>
  <h4>1º Ano</h4>
  <p>Português e Literatura: Revisão de linguagem verbal e não verbal, funções da linguagem, figuras de linguagem, coesão, coerência, intertextualidade, gêneros discursivos e estrutura de textos literários como poemas e sonetos. Além do português, incluem língua inglesa ou espanhola, arte e educação física.</p>
</section>
<section>
  <h4>2º Ano</h4>
  <p>Língua Portuguesa e Literatura: foco na interpretação de textos, gramática, redação e análise literária.</p>
</section>
<section>
  <h4>3º Ano</h4>
  <p>Aprofundamento em gramática e literatura, com foco na produção de textos dissertativos e argumentativos para vestibulares e ENEM.</p>
</section>

    </section>
    <footer class="footer">
      <p>Murilo Teixeira de Sousa — 17 anos — 3º ano EM & Curso Técnico em TI</p>
    </footer>
  </main>
</body>
</html>