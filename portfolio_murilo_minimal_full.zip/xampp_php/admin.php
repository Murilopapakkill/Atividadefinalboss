<?php
session_start();
require_once 'php/db.php';
$logged = $_SESSION['admin_logged'] ?? false;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['user'], $_POST['pass'])) {
    if ($_POST['user'] === 'admin' && $_POST['pass'] === '1234') {
        $_SESSION['admin_logged'] = true;
        header('Location: admin.php');
        exit;
    } else {
        $error = 'Credenciais inválidas';
    }
}
if (!$logged && $_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo '<!doctype html><html><body><p>Por favor, faça login via <a href="login.php">login</a>.</p></body></html>';
    exit;
}
$mysqli = get_db();
$res = $mysqli->query('SELECT id,name,email,message,created_at FROM messages ORDER BY created_at DESC');
$messages = $res ? $res->fetch_all(MYSQLI_ASSOC) : [];
?>
<!doctype html><html><head><meta charset="utf-8"><title>Admin — Murilo</title><link rel="stylesheet" href="css/style.css"></head><body>
<nav class="navbar"><div class="container nav-row"><a class="brand" href="home.php">Murilo Teixeira</a></div></nav>
<main class="container">
  <h1>Mensagens recebidas</h1>
  <p><a href="logout.php">Sair</a></p>
  <?php if(empty($messages)): ?>
    <p>Nenhuma mensagem.</p>
  <?php else: ?>
    <?php foreach($messages as $m): ?>
      <div class="card">
        <h4><?php echo htmlspecialchars($m['name']); ?> — <?php echo htmlspecialchars($m['email']); ?></h4>
        <p><?php echo nl2br(htmlspecialchars($m['message'])); ?></p>
        <small><?php echo htmlspecialchars($m['created_at']); ?></small>
      </div>
    <?php endforeach; ?>
  <?php endif; ?>
</main>
</body></html>
