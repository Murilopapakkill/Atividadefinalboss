<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Ciências Humanas — Murilo</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
  <nav class="navbar">
  <div class="container nav-row">
    <a class="brand" href="home.php">Murilo Teixeira</a>
    <ul class="nav-links">
      <li><a href="home.php">Home</a></li>
      <li><a href="sobre.php">Sobre</a></li>
      <li><a href="habilidades.php">Habilidades</a></li>
      <li><a href="softskills.php">Soft Skills</a></li>
      <li><a href="areas_overview.php">Áreas</a></li>
      <li><a href="tendencias.php">Tendências</a></li>
      <li><a href="contato.php">Contato</a></li>
    </ul>
    <a class="login" href="login.php">Admin</a>
  </div>
</nav>
  <main class="container">
    <header class="header">
      <h1>Ciências Humanas</h1>
    </header>
    <section class="card">
      <h3 class="section-title">Ciências Humanas</h3>
<section>
  <h4>1º Ano</h4>
  <p>História, geografia, filosofia e sociologia, com foco em temas como origem do universo, GPS, e a organização da sociedade.</p>
</section>
<section>
  <h4>2º Ano</h4>
  <p>História e Geografia: Estudo de períodos históricos mais específicos e aprofundamento em questões geopolíticas e sociais. Filosofia e Sociologia: introdução ao pensamento filosófico e às teorias sociais.</p>
</section>
<section>
  <h4>3º Ano</h4>
  <p>Aprofundamento em História, Geografia, Sociologia e Filosofia, com temas relevantes para o ENEM, como a história do Brasil e a sociologia contemporânea. Preparação para o ENEM e vestibulares e ensino técnico integrado quando aplicável.</p>
</section>

    </section>
    <footer class="footer">
      <p>Murilo Teixeira de Sousa — 17 anos — 3º ano EM & Curso Técnico em TI</p>
    </footer>
  </main>
</body>
</html>