<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Matemática — Murilo</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
  <nav class="navbar">
  <div class="container nav-row">
    <a class="brand" href="home.php">Murilo Teixeira</a>
    <ul class="nav-links">
      <li><a href="home.php">Home</a></li>
      <li><a href="sobre.php">Sobre</a></li>
      <li><a href="habilidades.php">Habilidades</a></li>
      <li><a href="softskills.php">Soft Skills</a></li>
      <li><a href="areas_overview.php">Áreas</a></li>
      <li><a href="tendencias.php">Tendências</a></li>
      <li><a href="contato.php">Contato</a></li>
    </ul>
    <a class="login" href="login.php">Admin</a>
  </div>
</nav>
  <main class="container">
    <header class="header">
      <h1>Matemática</h1>
    </header>
    <section class="card">
      <h3 class="section-title">Matemática</h3>
<section>
  <h4>1º Ano</h4>
  <p>Estudo de conjuntos numéricos (naturais, inteiros, racionais, irracionais e reais), operações, intervalos, funções (afim, quadrática, exponencial e modular), matemática financeira, geometria plana e relações métricas no triângulo retângulo.</p>
</section>
<section>
  <h4>2º Ano</h4>
  <p>Aprofunda em trigonometria (funções, equações e inequações), introduz matrizes e determinantes, e estuda geometria espacial (poliedros, prismas, pirâmides, cones, cilindros e esferas).</p>
</section>
<section>
  <h4>3º Ano</h4>
  <p>Introdução aos números complexos, geometria analítica (pontos, retas, etc.), equações polinomiais, estudo de funções e análise de gráficos, estatística e probabilidade.</p>
</section>

    </section>
    <footer class="footer">
      <p>Murilo Teixeira de Sousa — 17 anos — 3º ano EM & Curso Técnico em TI</p>
    </footer>
  </main>
</body>
</html>