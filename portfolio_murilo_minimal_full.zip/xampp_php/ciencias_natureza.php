<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Ciências da Natureza — Murilo</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
  <nav class="navbar">
  <div class="container nav-row">
    <a class="brand" href="home.php">Murilo Teixeira</a>
    <ul class="nav-links">
      <li><a href="home.php">Home</a></li>
      <li><a href="sobre.php">Sobre</a></li>
      <li><a href="habilidades.php">Habilidades</a></li>
      <li><a href="softskills.php">Soft Skills</a></li>
      <li><a href="areas_overview.php">Áreas</a></li>
      <li><a href="tendencias.php">Tendências</a></li>
      <li><a href="contato.php">Contato</a></li>
    </ul>
    <a class="login" href="login.php">Admin</a>
  </div>
</nav>
  <main class="container">
    <header class="header">
      <h1>Ciências da Natureza</h1>
    </header>
    <section class="card">
      <h3 class="section-title">Ciências da Natureza</h3>
<section>
  <h4>1º Ano</h4>
  <p>Introdução à química, física e biologia. A biologia foca em níveis de organização e métodos científicos, enquanto química e física exploram conceitos mais aprofundados.</p>
</section>
<section>
  <h4>2º Ano</h4>
  <p>Física: propriedades de líquidos e gases, termodinâmica, óptica, ondulatória, acústica e eletricidade. Química: funções inorgânicas e orgânicas, reações e estequiometria. Biologia: genética, evolução, ecologia e fisiologia humana.</p>
</section>
<section>
  <h4>3º Ano</h4>
  <p>Aprofundamento em Física, Química e Biologia, com ênfase em tópicos importantes para o ENEM, como genética, termodinâmica e química orgânica.</p>
</section>

    </section>
    <footer class="footer">
      <p>Murilo Teixeira de Sousa — 17 anos — 3º ano EM & Curso Técnico em TI</p>
    </footer>
  </main>
</body>
</html>