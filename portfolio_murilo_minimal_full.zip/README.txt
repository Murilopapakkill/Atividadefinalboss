Versão Minimalista — Portfólio Murilo
====================================

O pacote contém:
- static_html/  -> Versão estática (HTML) com páginas separadas.
- xampp_php/    -> Versão para XAMPP (PHP) com backend simples e script SQL.
  - php/db.php: ajustar credenciais se necessário.
  - php/contact.php: endpoint que salva mensagens no banco.
  - sql/create_db.sql: script para criar banco e inserir 12 mensagens de exemplo.

Instruções XAMPP:
1. Copie a pasta 'xampp_php' para C:\xampp\htdocs\portfolio_murilo
2. Inicie Apache e MySQL no painel XAMPP.
3. Abra http://localhost/phpmyadmin e importe sql/create_db.sql.
4. Acesse http://localhost/portfolio_murilo/home.php
5. Login admin (simples): usuário 'admin' senha '1234'

Se quiser que eu adicione projetos como registros em uma tabela 'projects' (para completar 20 registros) me avisa e eu atualizo.

