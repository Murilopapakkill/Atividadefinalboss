<?php require_once 'functions.php'; ?>
<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><title>Habilidades</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"></head>
<body><div class="container mt-4">
<a href="softskills_intro.php" class="btn btn-link">&larr; Voltar</a>
<h2>Habilidades</h2>
<h5>Técnicas</h5>
<ul><li>HTML, CSS, JavaScript</li><li>Bootstrap</li></ul>
<h5>Soft</h5>
<ul><li>Comunicação</li><li>Organização</li></ul>
</div></body></html>