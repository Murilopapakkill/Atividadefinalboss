<?php
require_once 'functions.php';
$projects = getProjects();
?>
<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Portfólio — Murilo</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { padding-top:70px; }
    .hero { background:#f8f9fa; padding:40px 0; }
    .card-img-top { height:160px; object-fit:cover; }
  </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top shadow-sm">
  <div class="container">
    <a class="navbar-brand" href="index.php">Portfólio</a>
    <button class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#nav">☰</button>
    <div class="collapse navbar-collapse" id="nav">
      <ul class="navbar-nav me-auto">
        <li class="nav-item"><a class="nav-link" href="humanas.php">Ciências Humanas</a></li>
        <li class="nav-item"><a class="nav-link" href="natureza.php">Ciências da Natureza</a></li>
        <li class="nav-item"><a class="nav-link" href="matematica.php">Matemática</a></li>
        <li class="nav-item"><a class="nav-link" href="linguagens.php">Linguagens</a></li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">Tendências</a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="ciberseguranca.php">Cibersegurança</a></li>
            <li><a class="dropdown-item" href="blockchain.php">Blockchain</a></li>
            <li><a class="dropdown-item" href="robotica.php">Automação e Robótica</a></li>
            <li><a class="dropdown-item" href="edge.php">Edge Computing</a></li>
          </ul>
        </li>
        <li class="nav-item"><a class="nav-link" href="softskills_intro.php">Soft Skills</a></li>
      </ul>
      <ul class="navbar-nav">
        <li class="nav-item"><a class="nav-link" href="softskills_contato.php">Contato</a></li>
        <li class="nav-item"><a class="nav-link" href="admin/login.php">Admin</a></li>
      </ul>
    </div>
  </div>
</nav>

<header class="hero">
  <div class="container">
    <div class="row align-items-center">
      <div class="col-md-8">
        <h1>Murilo Teixeira</h1>
        <p class="lead">Desenvolvedor front-end — HTML, CSS, JavaScript. Bem-vindo ao meu portfólio.</p>
        <p><a class="btn btn-primary" href="softskills_projetos.php">Ver projetos</a></p>
      </div>
      <div class="col-md-4 text-center">
        <img src="img/me.jpg" class="img-fluid rounded-circle" alt="Minha foto" style="max-width:160px;">
      </div>
    </div>
  </div>
</header>

<div class="container mt-4">
  <h3>Projetos recentes</h3>
  <div class="row gy-3">
    <?php foreach(array_slice($projects,0,8) as $p): ?>
      <div class="col-md-3">
        <div class="card h-100">
          <img src="<?php echo htmlspecialchars($p['image']); ?>" class="card-img-top" alt="">
          <div class="card-body d-flex flex-column">
            <h5 class="card-title"><?php echo htmlspecialchars($p['title']); ?></h5>
            <p class="small text-muted"><?php echo htmlspecialchars($p['category']); ?></p>
            <p class="mt-auto"><a href="softskills_projetos.php#proj<?php echo $p['id']; ?>" class="btn btn-sm btn-outline-primary">Ver</a></p>
          </div>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
</div>

<footer class="mt-4 py-4 bg-light">
  <div class="container text-center small text-muted">Portfólio desenvolvido para o Challenge 4º Bimestre — Canes Solution</div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>