<?php require_once 'functions.php'; ?>
<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><title>Blockchain</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"></head>
<body><div class="container mt-4">
<a href="index.php" class="btn btn-link">&larr; Voltar</a>
<h2>Blockchain</h2>
<p>Noções sobre blockchain e aplicações.</p>
<ul>
<li>Ponto 1</li><li>Ponto 2</li><li>Ponto 3</li>
</ul>
</div></body></html>