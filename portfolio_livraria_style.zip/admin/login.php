<?php
require_once '../functions.php';
if(isset($_SESSION['admin_logged']) && $_SESSION['admin_logged']) header('Location: dashboard.php');
$error = '';
if($_SERVER['REQUEST_METHOD'] === 'POST') {
  $email = $_POST['email'] ?? ''; $pass = $_POST['password'] ?? '';
  if(adminLogin($email,$pass)) header('Location: dashboard.php'); else $error = 'Credenciais inválidas';
}
?>
<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><title>Admin Login</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"></head>
<body><div class="container mt-4">
<h3>Admin — Login</h3>
<?php if($error): ?><div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>
<form method="post" style="max-width:420px">
  <div class="mb-2"><label>Email</label><input name="email" class="form-control" required></div>
  <div class="mb-2"><label>Senha</label><input name="password" type="password" class="form-control" required></div>
  <button class="btn btn-primary">Entrar</button>
</form>
</div></body></html>