<?php require_once '../functions.php'; if(!isset($_SESSION['admin_logged'])||!$_SESSION['admin_logged']){header('Location: login.php');exit;} ?>
<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><title>Dashboard</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"></head>
<body><div class="container mt-4">
<div class="d-flex justify-content-between align-items-center"><h3>Painel Admin</h3>
<div><a class="btn btn-sm btn-outline-secondary" href="messages.php">Mensagens</a> <a class="btn btn-sm btn-outline-secondary" href="projects.php">Projetos</a> <a class="btn btn-sm btn-danger" href="logout.php">Sair</a></div></div>
<hr>
<p>Gerencie mensagens e projetos.</p>
</div></body></html>