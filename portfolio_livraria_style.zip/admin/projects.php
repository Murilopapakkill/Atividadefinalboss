<?php require_once '../functions.php'; if(!isset($_SESSION['admin_logged'])||!$_SESSION['admin_logged']){header('Location: login.php');exit;} 
if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['action']) && $_POST['action']==='add') {
  $title = $_POST['title'] ?? ''; $category = $_POST['category'] ?? ''; $image = $_POST['image'] ?? ''; $desc = $_POST['description'] ?? '';
  $stmt = $pdo->prepare('INSERT INTO projects (title,category,image,description,created_at) VALUES (?,?,?,?,NOW())');
  $stmt->execute([$title,$category,$image,$desc]);
  header('Location: projects.php'); exit;
}
if(isset($_GET['delete'])) { $id=(int)$_GET['delete']; $stmt=$pdo->prepare('DELETE FROM projects WHERE id=?'); $stmt->execute([$id]); header('Location: projects.php'); exit; }
$stmt = $pdo->query('SELECT * FROM projects ORDER BY id DESC'); $projects = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><title>Projetos</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"></head>
<body><div class="container mt-4"><a href="dashboard.php" class="btn btn-link">&larr; Voltar</a><h3>Projetos</h3>
<div class="row"><div class="col-md-6">
<form method="post">
<input type="hidden" name="action" value="add">
<div class="mb-2"><label>Título</label><input name="title" class="form-control" required></div>
<div class="mb-2"><label>Categoria</label><input name="category" class="form-control"></div>
<div class="mb-2"><label>URL imagem</label><input name="image" class="form-control"></div>
<div class="mb-2"><label>Descrição</label><textarea name="description" class="form-control"></textarea></div>
<button class="btn btn-success">Adicionar</button>
</form></div>
<div class="col-md-6"><h5>Lista</h5><table class="table"><thead><tr><th>ID</th><th>Título</th><th></th></tr></thead><tbody><?php foreach($projects as $p): ?><tr><td><?php echo $p['id']; ?></td><td><?php echo htmlspecialchars($p['title']); ?></td><td><a href="projects.php?delete=<?php echo $p['id']; ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Remover?')">Remover</a></td></tr><?php endforeach; ?></tbody></table></div></div></div></body></html>