<?php require_once '../functions.php'; if(!isset($_SESSION['admin_logged'])||!$_SESSION['admin_logged']){header('Location: login.php');exit;} $msgs = getMessages(); ?>
<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><title>Mensagens</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"></head>
<body><div class="container mt-4">
<a href="dashboard.php" class="btn btn-link">&larr; Voltar</a>
<h3>Mensagens</h3>
<?php if(empty($msgs)): ?><p>Nenhuma mensagem.</p><?php else: ?>
  <?php foreach($msgs as $m): ?>
    <div class="card mb-2"><div class="card-body">
      <div class="d-flex justify-content-between"><div><strong><?php echo htmlspecialchars($m['name']); ?></strong> — <?php echo htmlspecialchars($m['email']); ?><div class="small text-muted"><?php echo $m['created_at']; ?></div></div>
      <div><a href="messages_view.php?id=<?php echo $m['id']; ?>" class="btn btn-sm btn-outline-primary">Ver</a></div></div>
    </div></div>
  <?php endforeach; ?>
<?php endif; ?>
</div></body></html>