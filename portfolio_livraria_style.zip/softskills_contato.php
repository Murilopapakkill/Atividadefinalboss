<?php require_once 'functions.php'; $success = ''; $errors = []; 
if($_SERVER['REQUEST_METHOD'] === 'POST') {
  $name = trim($_POST['name'] ?? ''); $email = trim($_POST['email'] ?? ''); $msg = trim($_POST['message'] ?? '');
  if($name === '' || $email === '' || $msg === '') $errors[] = 'Preencha todos os campos.';
  if(empty($errors)) { createMessage($name,$email,$msg); $success = 'Mensagem enviada! Obrigado.'; }
}
?>
<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><title>Contato</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"></head>
<body><div class="container mt-4">
<a href="index.php" class="btn btn-link">&larr; Voltar</a>
<h2>Contato</h2>
<?php if($success): ?><div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div><?php endif; ?>
<?php if($errors): ?><div class="alert alert-danger"><?php echo implode('<br>', array_map('htmlspecialchars',$errors)); ?></div><?php endif; ?>
<form method="post" style="max-width:600px">
  <div class="mb-2"><label>Nome</label><input name="name" class="form-control" required></div>
  <div class="mb-2"><label>Email</label><input name="email" type="email" class="form-control" required></div>
  <div class="mb-2"><label>Mensagem</label><textarea name="message" class="form-control" rows="5" required></textarea></div>
  <button class="btn btn-primary">Enviar</button>
</form>
</div></body></html>