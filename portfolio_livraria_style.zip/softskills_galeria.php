<?php require_once 'functions.php'; ?>
<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><title>Galeria</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"></head>
<body><div class="container mt-4">
<a href="softskills_intro.php" class="btn btn-link">&larr; Voltar</a>
<h2>Galeria</h2>
<div class="row gy-3">
  <div class="col-md-4"><img src="img/sample1.jpg" class="img-fluid rounded"></div>
  <div class="col-md-4"><img src="img/sample2.jpg" class="img-fluid rounded"></div>
  <div class="col-md-4"><img src="img/sample3.jpg" class="img-fluid rounded"></div>
</div>
</div></body></html>