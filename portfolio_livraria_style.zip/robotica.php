<?php require_once 'functions.php'; ?>
<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><title>Automação e Robótica</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"></head>
<body><div class="container mt-4">
<a href="index.php" class="btn btn-link">&larr; Voltar</a>
<h2>Automação e Robótica</h2>
<p>Automação, sensores e robótica aplicada.</p>
<ul>
<li>Ponto 1</li><li>Ponto 2</li><li>Ponto 3</li>
</ul>
</div></body></html>