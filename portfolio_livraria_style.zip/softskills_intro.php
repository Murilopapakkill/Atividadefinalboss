<?php require_once 'functions.php'; ?>
<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><title>Soft Skills — Introdução</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"></head>
<body><div class="container mt-4">
<a href="index.php" class="btn btn-link">&larr; Voltar</a>
<h2>Soft Skills</h2>
<p>Breve apresentação sobre soft skills e sua importância.</p>
<ul>
<li>Comunicação</li><li>Trabalho em equipe</li><li>Resolução de problemas</li>
</ul>
</div></body></html>