CREATE DATABASE IF NOT EXISTS portfolio_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE portfolio_db;

DROP TABLE IF EXISTS users;
CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  role ENUM('admin','user') NOT NULL DEFAULT 'user',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

DROP TABLE IF EXISTS projects;
CREATE TABLE projects (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  category VARCHAR(150),
  image VARCHAR(512),
  description TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

DROP TABLE IF EXISTS messages;
CREATE TABLE messages (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150),
  email VARCHAR(150),
  message TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- seed users (2)
INSERT INTO users (name,email,password,role) VALUES
('Admin','admin@demo','$2b$12$5z5Df4JdCObz1z9ZgZahhuw4f3BDREtfTy0aUKbEL6t9a3HjXHA.q','admin'),
('Demo User','user@demo','$2b$12$5z5Df4JdCObz1z9ZgZahhuw4f3BDREtfTy0aUKbEL6t9a3HjXHA.q','user');

-- seed projects (12)
INSERT INTO projects (title,category,image,description) VALUES
('Website Escola','Ciências Humanas','https://picsum.photos/seed/p1/400/300','Projeto de site escolar.'),
('Mapa Mental','Ciências Humanas','https://picsum.photos/seed/p2/400/300','Mapa mental sobre conflitos.'),
('Simulação Física','Ciências da Natureza','https://picsum.photos/seed/p3/400/300','Experimento virtual.'),
('Relatório Química','Ciências da Natureza','https://picsum.photos/seed/p4/400/300','Relatório sobre reações.'),
('App Matemática','Matemática','https://picsum.photos/seed/p5/400/300','App para prática de cálculo.'),
('Gráficos Dinâmicos','Matemática','https://picsum.photos/seed/p6/400/300','Visualização de funções.'),
('Projeto Literatura','Linguagens','https://picsum.photos/seed/p7/400/300','Análise literária.'),
('Podcast','Linguagens','https://picsum.photos/seed/p8/400/300','Episódio sobre autores.'),
('Mini Bot','Tecnologia','https://picsum.photos/seed/p9/400/300','Bot simples em JS.'),
('Dashboard','Tecnologia','https://picsum.photos/seed/p10/400/300','Dashboard em Bootstrap.'),
('Jogo Educativo','Tecnologia','https://picsum.photos/seed/p11/400/300','Jogo para ensino.'),
('Portfolio Template','Design','https://picsum.photos/seed/p12/400/300','Template de portfólio.');

-- seed messages (6)
INSERT INTO messages (name,email,message) VALUES
('Alice','alice@mail.com','Ótimo portfólio!'),
('Bruno','bruno@mail.com','Tenho interesse no projeto X.'),
('Carla','carla@mail.com','Como posso colaborar?'),
('Daniel','daniel@mail.com','Parabéns pelo trabalho.'),
('Eduarda','edu@mail.com','Gostaria de mais detalhes.'),
('Felipe','felipe@mail.com','Contato para freelance.');

-- total records: users(2)+projects(12)+messages(6) = 20
