<?php require_once 'functions.php'; $projects = getProjects(); ?>
<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><title>Projetos</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"></head>
<body><div class="container mt-4">
<a href="softskills_intro.php" class="btn btn-link">&larr; Voltar</a>
<h2>Projetos</h2>
<div class="row gy-3">
  <?php foreach($projects as $p): ?>
    <div class="col-md-4" id="proj<?php echo $p['id']; ?>">
      <div class="card h-100">
        <img src="<?php echo htmlspecialchars($p['image']); ?>" class="card-img-top" alt="">
        <div class="card-body d-flex flex-column">
          <h5><?php echo htmlspecialchars($p['title']); ?></h5>
          <p class="small text-muted"><?php echo htmlspecialchars($p['category']); ?></p>
          <p class="mt-auto"><?php echo nl2br(htmlspecialchars($p['description'])); ?></p>
        </div>
      </div>
    </div>
  <?php endforeach; ?>
</div>
</div></body></html>