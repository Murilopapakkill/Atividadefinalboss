<?php require_once 'functions.php'; ?>
<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><title>Matemática</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"></head>
<body><div class="container mt-4">
<a href="index.php" class="btn btn-link">&larr; Voltar</a>
<h2>Matemática</h2>
<p>Aqui estão meus melhores trabalhos em Matemática.</p>
<div class="row gy-3">
  <div class="col-md-4"><div class="card p-3">Melhor trabalho 1</div></div>
  <div class="col-md-4"><div class="card p-3">Melhor trabalho 2</div></div>
  <div class="col-md-4"><div class="card p-3">Melhor trabalho 3</div></div>
</div>
</div></body></html>