<?php
require 'config.php';
$pass = 'admin123';
$hash = password_hash($pass, PASSWORD_DEFAULT);
$stmt = $pdo->prepare('UPDATE users SET password = ? WHERE email = ?');
$stmt->execute([$hash, 'admin@demo']);
echo 'Admin password hashed/updated.';
?>