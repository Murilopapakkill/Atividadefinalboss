<?php
require_once 'config.php';

// Projetos (CRUD simples)
function getProjects() {
    global $pdo;
    $stmt = $pdo->query('SELECT * FROM projects ORDER BY created_at DESC');
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}
function getProject($id) {
    global $pdo;
    $stmt = $pdo->prepare('SELECT * FROM projects WHERE id = ?');
    $stmt->execute([(int)$id]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

// Mensagens do formulário de contato
function createMessage($name, $email, $message) {
    global $pdo;
    $stmt = $pdo->prepare('INSERT INTO messages (name,email,message,created_at) VALUES (?,?,?,NOW())');
    $stmt->execute([$name,$email,$message]);
    return $pdo->lastInsertId();
}
function getMessages() {
    global $pdo;
    $stmt = $pdo->query('SELECT * FROM messages ORDER BY created_at DESC');
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}
function getMessage($id) {
    global $pdo;
    $stmt = $pdo->prepare('SELECT * FROM messages WHERE id = ?');
    $stmt->execute([(int)$id]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

// Admin auth (very simple)
function adminLogin($email, $password) {
    global $pdo;
    $stmt = $pdo->prepare('SELECT * FROM users WHERE email = ? AND role = "admin"');
    $stmt->execute([$email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    if($user && password_verify($password, $user['password'])) {
        $_SESSION['admin_logged'] = true;
        $_SESSION['admin_id'] = $user['id'];
        return true;
    }
    return false;
}
function adminLogout() {
    unset($_SESSION['admin_logged']);
    unset($_SESSION['admin_id']);
}
?>